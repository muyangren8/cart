create trigger HAO_KA_YU_YUE_TRG
    before insert
    on "号卡线上预约"
    for each row
    when (NEW.ID IS NULL)
BEGIN
SELECT SEQ_hao_ka_yu_yue.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

