create trigger TRIGGER_WEB_SYSTEM_PROPOSE
    before insert
    on WEB_SYSTEM_PROPOSE
    for each row
begin
 select Sequence_web_system_propose.nextval into:New.id from dual;
 end;
/

