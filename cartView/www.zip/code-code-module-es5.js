(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["code-code-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/code/code.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/code/code.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>用户校验</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <div class=\"code_info\">\n    <p class=\"code_sign_p\">验证码已通过短信方式发送至{{phone}}，请输入验证码完成验证，用户校验是为了验证用户的真实性和账号安全</p>\n  </div>\n\n  <div class=\"sign_info\">\n\n    <input type=\"text\" placeholder=\"验证码\" [(ngModel)]=\"code\" (ionChange)=\"checkCode()\"/>\n    <div class=\"timer\" *ngIf=\"!sendCodeBtn\">\n      倒计时{{num}}\n    </div>\n\n    <div class=\"timer\" *ngIf=\"sendCodeBtn\" (click)=\"sendCode()\" >\n      重新发送验证码\n    </div>\n  </div>\n  <ion-button (click)=\"doRegister3()\" expand=\"block\" color=\"danger\" class=\"login_btn\">\n    立即签约\n  </ion-button>\n\n\n</ion-content>"

/***/ }),

/***/ "./src/app/code/code.module.ts":
/*!*************************************!*\
  !*** ./src/app/code/code.module.ts ***!
  \*************************************/
/*! exports provided: CodePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CodePageModule", function() { return CodePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _code_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./code.page */ "./src/app/code/code.page.ts");







var routes = [
    {
        path: '',
        component: _code_page__WEBPACK_IMPORTED_MODULE_6__["CodePage"]
    }
];
var CodePageModule = /** @class */ (function () {
    function CodePageModule() {
    }
    CodePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_code_page__WEBPACK_IMPORTED_MODULE_6__["CodePage"]]
        })
    ], CodePageModule);
    return CodePageModule;
}());



/***/ }),

/***/ "./src/app/code/code.page.scss":
/*!*************************************!*\
  !*** ./src/app/code/code.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".code_info h4 {\n  font-size: 1rem;\n  padding: 0.5rem 0px;\n}\n.code_info p {\n  font-size: 1rem;\n  color: #666;\n}\n.sign_info {\n  margin: 2rem 0px;\n  display: -webkit-box;\n  display: flex;\n}\n.sign_info input {\n  -webkit-box-flex: 1;\n          flex: 1;\n  height: 3.2rem;\n  line-height: 3.2rem;\n  border: 1px solid #eee;\n  text-indent: 1rem;\n}\n.sign_info .timer {\n  width: 10rem;\n  height: 3.2rem;\n  line-height: 3.2rem;\n  background: #eee;\n  text-align: center;\n  margin-left: 1rem;\n  border: 1px solid #eee;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29kZS9DOlxcaW9uaWNcXGNhcnRcXGNhcnRWaWV3L3NyY1xcYXBwXFxjb2RlXFxjb2RlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvY29kZS9jb2RlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFSTtFQUVJLGVBQUE7RUFDQSxtQkFBQTtBQ0ZSO0FES0k7RUFFSSxlQUFBO0VBRUEsV0FBQTtBQ0xSO0FEU0E7RUFFSSxnQkFBQTtFQUVBLG9CQUFBO0VBQUEsYUFBQTtBQ1JKO0FEU0k7RUFDSSxtQkFBQTtVQUFBLE9BQUE7RUFFQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0FDUlI7QURZSTtFQUVJLFlBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFFQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxzQkFBQTtBQ1pSIiwiZmlsZSI6InNyYy9hcHAvY29kZS9jb2RlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb2RlX2luZm97XHJcblxyXG4gICAgaDR7XHJcblxyXG4gICAgICAgIGZvbnQtc2l6ZTogMXJlbTtcclxuICAgICAgICBwYWRkaW5nOiAuNXJlbSAwcHg7XHJcbiAgICB9XHJcblxyXG4gICAgcHtcclxuXHJcbiAgICAgICAgZm9udC1zaXplOiAxcmVtO1xyXG5cclxuICAgICAgICBjb2xvcjogIzY2NjtcclxuICAgIH1cclxufVxyXG5cclxuLnNpZ25faW5mb3tcclxuXHJcbiAgICBtYXJnaW46IDJyZW0gMHB4O1xyXG5cclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBpbnB1dHtcclxuICAgICAgICBmbGV4OjE7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaGVpZ2h0OiAzLjJyZW07XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDMuMnJlbTtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZWVlO1xyXG4gICAgICAgIHRleHQtaW5kZW50OiAxcmVtO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICAudGltZXJ7XHJcblxyXG4gICAgICAgIHdpZHRoOiAxMHJlbTtcclxuICAgICAgICBoZWlnaHQ6IDMuMnJlbTtcclxuICAgICAgICBsaW5lLWhlaWdodDogMy4ycmVtO1xyXG5cclxuICAgICAgICBiYWNrZ3JvdW5kOiAjZWVlO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBtYXJnaW4tbGVmdDoxcmVtO1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNlZWU7XHJcbiAgICB9XHJcbn0iLCIuY29kZV9pbmZvIGg0IHtcbiAgZm9udC1zaXplOiAxcmVtO1xuICBwYWRkaW5nOiAwLjVyZW0gMHB4O1xufVxuLmNvZGVfaW5mbyBwIHtcbiAgZm9udC1zaXplOiAxcmVtO1xuICBjb2xvcjogIzY2Njtcbn1cblxuLnNpZ25faW5mbyB7XG4gIG1hcmdpbjogMnJlbSAwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG4uc2lnbl9pbmZvIGlucHV0IHtcbiAgZmxleDogMTtcbiAgaGVpZ2h0OiAzLjJyZW07XG4gIGxpbmUtaGVpZ2h0OiAzLjJyZW07XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlZWU7XG4gIHRleHQtaW5kZW50OiAxcmVtO1xufVxuLnNpZ25faW5mbyAudGltZXIge1xuICB3aWR0aDogMTByZW07XG4gIGhlaWdodDogMy4ycmVtO1xuICBsaW5lLWhlaWdodDogMy4ycmVtO1xuICBiYWNrZ3JvdW5kOiAjZWVlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi1sZWZ0OiAxcmVtO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZWVlO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/code/code.page.ts":
/*!***********************************!*\
  !*** ./src/app/code/code.page.ts ***!
  \***********************************/
/*! exports provided: CodePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CodePage", function() { return CodePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/http.service */ "./src/app/services/http.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





var CodePage = /** @class */ (function () {
    function CodePage(http, storage, nav) {
        this.http = http;
        this.storage = storage;
        this.nav = nav;
        this.cid = '';
        this.phone = '';
        this.code = '';
        this.sendCodeBtn = false;
        this.num = 30;
        this.cid = this.storage.get('cid');
        this.phone = this.storage.get('phone');
    }
    CodePage.prototype.ngOnInit = function () {
        this.doTimer();
    };
    CodePage.prototype.back = function () {
        this.nav.navigateBack('/tabs/tab2');
    };
    CodePage.prototype.doRegister3 = function () {
        var _this = this;
        this.http.ajaxGet('/market/sso/checkCode?phone=' + this.phone + '&code=' + this.code).then(function (response) {
            console.log(response);
            if (response.status == 200) {
                //保存验证码
                _this.nav.navigateForward('/sign-page');
            }
            else {
                alert('验证码验证失败，请重新验证');
            }
        });
    };
    //倒计时
    CodePage.prototype.doTimer = function () {
        var _this = this;
        var timer = setInterval(function () {
            _this.num--;
            if (_this.num == 0) {
                _this.sendCodeBtn = true;
                clearInterval(timer);
            }
        }, 1000);
    };
    //重新发送验证码
    CodePage.prototype.sendCode = function () {
        var _this = this;
        this.http.ajaxGet("/market/sso/getCode?cid=" + this.cid).then(function (response) {
            console.log(response);
            if (response.status == 200) {
                alert('发送验证码成功');
                _this.num = 30;
                _this.sendCodeBtn = false;
                _this.doTimer();
            }
            else {
                alert(response.msg);
            }
        });
    };
    CodePage.ctorParameters = function () { return [
        { type: _services_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] }
    ]; };
    CodePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-code',
            template: __webpack_require__(/*! raw-loader!./code.page.html */ "./node_modules/raw-loader/index.js!./src/app/code/code.page.html"),
            styles: [__webpack_require__(/*! ./code.page.scss */ "./src/app/code/code.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"], _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])
    ], CodePage);
    return CodePage;
}());



/***/ })

}]);
//# sourceMappingURL=code-code-module-es5.js.map