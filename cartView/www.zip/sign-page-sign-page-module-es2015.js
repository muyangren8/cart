(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sign-page-sign-page-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/sign-page/sign-page.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/sign-page/sign-page.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>5G业务测试活动协议（定向邀请）</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"doSign()\">\n        提交\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <div>\n    <div>\n      <p style=\"margin:0px 0px 5px; orphans:0; text-align:justify; widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">甲方名称：</span>\n        <span\n          style=\"background-color:#d8d8d8; font-family:仿宋; font-size:14px; font-weight:bold; text-decoration:underline\">\n          {{cname}}\n        </span>\n      </p>\n      <p style=\"margin:0px 0px 5px; orphans:0; text-align:justify; widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">乙方名称：</span>\n        <span style=\"font-family:仿宋; font-size:14px\">中国移动通信集团浙江有限公司宁波分公司</span>\n      </p>\n      <br>\n      <p style=\"margin:0px 0px 5px; orphans:0; text-align:justify; widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold;text-decoration:underline\"\n          [routerLink]=\"[ '/policy']\">查看政策详情</span>\n      </p>\n      <br>\n      <p\n        style=\"font-size:14px; line-height:150%; margin:0px; orphans:0; text-align:justify; text-indent:20px;  widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          根据《中华人民共和国合同法》、《中华人民共和国电信条例》以及相关法律、法规，甲、乙双方在平等、自愿、公平、诚实、信用的基础上，\n          就甲方参与由乙方组织和实施的5G业务测试活动（“测试活动”），达成协议如下：\n        </span>\n      </p>\n      <br>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-42pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px;font-weight:bold\">一、测试期间</span>\n      </p>\n      <p\n        style=\"font-size:14px; line-height:150%; margin:0px; orphans:0; text-align:justify; text-indent:20px;  widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px;float: left;\">\n          <ion-datetime style=\"padding: 0px;font-family:仿宋;\" class=\"datetime\" displayFormat=\"YYYY年MM月DD日\"\n            pickerFormat=\"YYYY-MM-DD\" placeholder=\"点击选择起始日期\" [(ngModel)]=\"sign.planStartDate\"></ion-datetime>\n        </span>\n        <span style=\"font-family:仿宋; font-size:14px;float:left\">起至</span>\n        <span style=\"font-family:仿宋; font-size:14px;float:left\">\n          <ion-datetime style=\"padding: 0px;font-family:仿宋;\" class=\"datetime\" displayFormat=\"YYYY年MM月DD日\"\n            pickerFormat=\"YYYY-MM-DD\" placeholder=\"点击选择截至日期\" [(ngModel)]=\"sign.planEndDate\"></ion-datetime>\n        </span>\n        <br>\n        <!-- <span style=\"font-family:仿宋; font-size:14px;float:right\"> </span> -->\n      </p>\n      <br>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-42pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">二、测试内容</span>\n      </p>\n      <p\n        style=\"font-size:14px; line-height:150%; margin:0px; orphans:0; text-align:justify; text-indent:20px;  widows:0 \">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          甲方在乙方5G业务测试活动开展的5G网络覆盖范围内，自愿参与乙方组织的5G业务测试活动。甲方对于以下内容明确知晓且接受：\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          2.1. 乙方提供的5G网络的覆盖范围及漫游到其它网络的范围，将随5G业务测试活动的开展而随时调整。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          2.2. 为保证甲方顺利参与测试活动，乙方负责在协议有效期内为甲方提供测试用终端及测试所用的带中国移动手机号码的USIM卡，\n          具体号码和终端的型号由乙方指定，且在测试期间该号码不可进行号码携带转网。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          2.3. 乙方在测试期间将在5G网络所能支持的技术范围内保障相关网络的服务质量、业务质量及终端质量。</span>\n        <span style=\"font-family:仿宋; font-size:14px;font-weight: bold\">\n          但因应用测试期的网络服务存在相当的不确定性，不等同于正式商用的服务质量、业务质量及终端质量。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          2.4. 甲方应当在测试期间充分履行4.1款所约定的主要配合测试义务。\n        </span>\n      </p>\n      <br>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">三、资费标准</span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          3.1. 甲方在测试期间选择乙方提供优惠套餐\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:1pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px;display:block;; text-indent:30px\">\n          A、“飞悦98移宽福”（\n          <span\n            style=\"background-color:#d8d8d8; font-family:仿宋; font-size:14px; font-weight:bold; text-decoration:underline\">\n            <input type=\"number\" style=\"width: 40px;height: 14px;\" [(ngModel)]=\"sign.aPlanNum\" />\n          </span>\n          ）户\n        </span>\n        <span style=\"font-family:仿宋; font-size:14px;display:block;; text-indent:30px\">\n          B、“集团统付敬业福”（\n          <span\n            style=\"background-color:#d8d8d8; font-family:仿宋; font-size:14px; font-weight:bold; text-decoration:underline\">\n            <input type=\"number\" style=\"width: 40PX;height:14px;\" [(ngModel)]=\"sign.bPlanNum\" />\n          </span>\n          ）户\n        </span>\n        <span style=\"font-family:仿宋; font-size:14px;display:block;; text-indent:30px\">\n          C、“集团专线尊享福”（\n          <span\n            style=\"background-color:#d8d8d8; font-family:仿宋; font-size:14px; font-weight:bold; text-decoration:underline\">\n            <input type=\"number\" style=\"width: 40px;height: 14px;\" [(ngModel)]=\"sign.cPlanNum\" />\n          </span>\n          ）户\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:0pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          若甲方产生套餐外的其他消费，乙方有权按现行的资费标准额外收取相关费用。\n        </span>\n        <span style=\"font-family:仿宋; font-size:14px;font-weight: bold\">\n          甲方应按时向乙方交纳套餐外的相关费用，甲方超过约定交费日未交足费用，乙方有权暂停提供本合同约定的各项服务。\n        </span>\n        <span style=\"font-family:仿宋; font-size:14px\">\n          涉及优惠套餐内容参见附件《5G通信服务优惠方案》\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          3.2. 测试期间的计费周期为自然月，即每月第一日至当月最后一日（由于网络设备产生话单及相关处理会有时延，\n          可能发生每月部分话费计入下月话费中收取的情况，甲方对此表示明确知晓且接受）。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          3.3. 为鼓励甲方有效参与测试活动，乙方在本协议生效之日为测试集团提供特惠套餐，套餐优惠期与本协议中规定的测试期间保持一致。\n        </span>\n        <span style=\"font-family:仿宋; font-size:14px;font-weight: bold\">\n          套餐内包含的流量、语音、短信等仅限当月使用，不能转结至次月，不能退费折现。\n        </span>\n      </p>\n      <br>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-42pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">四、甲方权利及义务</span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">4.1. 甲方申请参与5G业务测试的流程：</span>\n        <span style=\"font-family:仿宋; font-size:14px;display:block;; text-indent:1pt\">（一）应当首先满足下列条件</span>\n        <span style=\"font-family:仿宋; font-size:14px;display:block;; text-indent:1pt\">1）是中国移动通信网络个人客户；</span>\n        <span\n          style=\"font-family:仿宋; font-size:14px;display:block;; text-indent:1pt\">2）连续在网时长、月平均消费话费、月流量使用量等方面满足乙方要求的条件。</span>\n        <span\n          style=\"font-family:仿宋; font-size:14px;display:block;; text-indent:1pt\">（二）在签订合同前，甲方需提交测试申请，以证明前述条件，提交的测试申请材料包括：</span>\n        <span\n          style=\"font-family:仿宋; font-size:14px;display:block;; text-indent:1pt\">1）《电话用户真实身份信息登记规定》（工业和信息化部令第25号）规定的有效证件；</span>\n        <span style=\"font-family:仿宋; font-size:14px;display:block;; text-indent:1pt\">2）甲方集团使用的中国移动号码。</span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          4.2. 甲方在测试期间的主要配合测试义务如下：甲方应保证在测试期间其本合同首页中的甲方测试所用手机号码状态正常，即不欠费、不停机。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          4.3. 甲方在测试期间不得重复参与乙方组织的与本协议相同或类似的业务测试活动。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          4.4. 甲方不得利用乙方提供的服务从事违法犯罪活动或违背公序良俗的活动，不得发送违法信息或未经接收客户同意发送骚扰信息，\n          不得有拨打骚扰电话等不当行为，否则，乙方可以暂停向甲方提供服务，直至终止服务。\n        </span>\n      </p>\n      <br>\n      <p style=\"font-size:14px; line-height:130%; margin:0px; orphans:0; text-align:justify;  widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">五、乙方权利及义务</span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          5.1. 乙方根据5G测试期间的技术及设备条件，在网络技术系统允许的范围内为甲方提供通信服务，测试期间5G信号可能不连续覆盖，\n          可能无法达到正式商用的通信质量标准和覆盖范围，乙方的通信质量可能会受影响，甲方对此已明确知晓并同意。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          5.2. 乙方通过营业厅、网站或短信等方式向甲方通知服务项目、服务时限、服务范围、资费标准、资费调整及补贴金额调整等内容，\n          乙方发布的上述通知视为本合同的有效组成部分。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          5.3. 乙方向甲方提供业务办理、业务咨询和投诉、话费信息查询的渠道，包括但不限于营业厅、服务热线、网站公告、短信等。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          5.4. 乙方有义务采取公布客服电话等形式受理甲方投诉，客服电话为10086。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          5.5. 乙方对测试产生的话费数据及信息服务计费数据保留期限为6个月(系统产生客户话单当月起后6个月，不含当月)，\n          对甲方在数据保留期限内提出异议的话单，应保存至异议解决为止。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          5.6. 若甲方对乙方收取的话费有异议，乙方将进行调查、解释，并告知甲方核实处理的结果。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          5.7. 乙方不得侵害甲方的通信自由和通信秘密，对甲方的客户资料负有保密义务。但根据法律法规规定，\n          乙方应配合公安机关、人民检察院、国家安全机关及其它法定有权机关进行侦查、调查工作的情况除外。\n        </span>\n      </p>\n      <br>\n      <p style=\"font-size:14px; line-height:130%; margin:0px; orphans:0; text-align:justify;  widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">六、特定责任承担</span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          6.1. 对于在此次5G业务测试活动中发生的异议，双方应通过友好协商解决，甲方无权向与此次测试活动无关的第三方披露任何信息。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          6.2. 此次5G业务测试活动中甲方提供的使用情况说明、测试情况报告等数据，乙方有权在测试活动需要的范围内使用，未经乙方同意，\n          甲方不得向无关的第三方披露。甲方同意，为了完善5G业务和实现本协议目的的需要，乙方可将上述数据与乙方关联公司共享。\n          乙方关联公司是指乙方现在或将来控制、受控制或与其处于共同控制下的任何公司、机构以及上述公司或机构的合法继承人。\n          其中“控制”是指直接或间接地拥有影响所提及公司管理的能力，无论是通过所有权、有投票权的股份、合同或其他被人民法院认定的方式。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          6.3. 当甲方遇到移动电话通信障碍时（指交换设备或传输线路原因造成通信中断等现象，不包括网络覆盖和终端设备故障），\n          甲方应尽快向乙方申报，以便乙方尽快修复或者调通。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px;font-weight: bold\">\n          6.4. 甲方参与测试活动后，入网时应设置客户服务密码，服务密码是甲方业务办理的重要凭证，甲方应妥善保管。\n          使用甲方服务密码定制、变更、取消业务的行为，均被视为甲方的有效行为或甲方授权的有效行为。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          6.5. 因不可抗力（是指不能预见、不能避免、不能克服的客观情况，包括但不限于暴雨、洪水、火灾、干旱、风暴、台风、\n          飓风、暴风雪、泥石流、地震、爆炸、雷电、瘟疫及其他自然灾害，以及电磁干扰、战争、暴乱、政府行为、法律或政策变化、\n          罢工，以及双方一致认为是不可抗力的其它情况）而使本协议部分或全部不能履行，双方互不承担违约责任。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px;font-weight: bold\">\n          6.6. 因一方违约给对方造成损失的，违约方应当向守约方依法承担赔偿责任，但该赔偿责任不应当包括对预期利润、\n          商业信誉、第三方损失以及其他任何间接损失的赔偿。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px;font-weight: bold\">\n          6.7. 因国家政策或甲方上级公司政策变化而导致本协议提前终止，乙方不承担违约责任。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          6.8. 由于5G业务处于测试阶段，网络技术可能存在不稳定性，甲方应自备4G通信终端。如果因为测试网络质量问题导致甲方通信不畅，\n          由此导致的任何不利影响或损失，甲方同意不追究乙方的法律责任。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          6.9. 甲方确认，乙方依据本合同所提供的测试终端为未取得工信部入网许可的试用品，上述试用品非甲方以现金或其他支付行为购买取得，\n          甲方仅具有使用权，为终端的无偿试用者，甲乙双方之间并非买卖合同关系。在测试期间，如果甲方发现测试终端有任何缺陷、问题，\n          甲方应当及时积极地反馈给乙方。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          6.10. 甲方确认，乙方依据本合同所提供的资费标准范围内的5G业务为试用服务，非甲方以现金或其他支付行为购买取得。在资费标准范围内的测试活动，\n          甲方仅为无偿试用者，甲乙双方之间并非有偿服务合同关系。在测试期间，如果甲方发现5G业务服务有任何缺陷、问题，甲方应当及时积极地反馈给乙方。\n        </span>\n      </p>\n      <br>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-42pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">七、协议的变更、转让及终止</span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          7.1. 为本合同目的，甲方办理各类业务时所签署的表单应当视为本协议的补充协议。如果补充协议条款与本协议存在冲突，以补充协议为准。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          7.2. 根据业务测试活动开展的需要，乙方有权修改资费方案及补贴政策，但应当提前3天通过网站公告、短信、电话等形式通知甲方。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          7.3. 未经乙方书面同意，甲方不得将本协议项下的任何权利、义务全部或部分转让给任何第三人。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          7.4. 甲方可以单方解除本协议，但应当书面通知乙方。乙方在收到甲方提出的终止协议的通知当日即终止向甲方提供本协议项下的通信服务，\n          在甲方归还乙方终端、支付所有欠付费用以及履行完本协议要求的其他义务后，本协议终止。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;font-weight: bold\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          7.5. 下列情况下乙方有权解除协议，收回测试终端和号码，甲方不因此追究乙方的任何责任：\n        </span>\n        <span style=\"font-family:仿宋; font-size:14px;display:block; text-indent:1pt\">（1）甲方和/或甲方的代理人提供的有效证件虚假不实；</span>\n        <span\n          style=\"font-family:仿宋; font-size:14px;display:block; text-indent:1pt\">（2）移动电话被用于违法犯罪活动或不当用途（有损乙方或相关第三方利益）；</span>\n        <span\n          style=\"font-family:仿宋; font-size:14px;display:block; text-indent:1pt\">（3）乙方收到有权国家机关的书面通知，要求停止为甲方提供通信服务；</span>\n        <span style=\"font-family:仿宋; font-size:14px;display:block; text-indent:1pt\">（4）甲方未能履行协议约定的任一义务的。</span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;font-weight: bold\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          7.6. 测试期满后或本协议约定的合同解除条件成就时，本协议终止。乙方保留向甲方追缴所欠费用的权利。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          7.7. 乙方根据国家政策对5G网络进行调整而导致本协议无法继续履行的，乙方应在解除协议之前告知甲方。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;font-weight: bold\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          7.8. 乙方对各种变动采用的通知方式包括但不限于短信、网站公告、电话等。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-42pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">八、其它约定</span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          8.1. 因本协议引起的或与本协议有关的任何争议，双方可协商解决，协商不成的，双方可向电信管理部门申诉或向消费者协会等有关部门投诉，\n          如仍不能解决，则将争议提交至乙方所在地人民法院诉讼解决。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px\">\n          8.2. 本合同为电子合同，经系统校验（手机验证码形式）签约人为甲方集团法人或为委托经办人后，经甲方签字后生效。\n        </span>\n      </p>\n      <p style=\"margin:0pt 0pt 0pt 42pt; orphans:0; text-align:justify; text-indent:-21pt; widows:0;\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">&#xa0;</span>\n      </p>\n\n    </div>\n    <div>\n      <p style=\"width:47%;font-size: 14px; line-height:150%;margin:0px;widows:0;float: left;\">\n        <span style=\"font-family:仿宋; font-size:14px\">甲方：（盖章） </span><br>\n        <ion-button (click)=\"toSignA()\" *ngIf=\"!sign.signatureImageA\" color=\"danger\" size=\"small\">\n            点击签名\n          </ion-button>\n          <img [src]=\"sign.signatureImageA\" *ngIf=\"sign.signatureImageA\" (click)=\"toSignA()\" />\n        <span style=\"font-family:仿宋; font-size:14px\">甲方代表：</span><br>\n        <span style=\"font-family:仿宋; font-size:14px\">{{cname}}</span><br>        \n        <span style=\"font-family:仿宋; font-size:14px\">\n          <ion-datetime style=\"padding-left: 0px;font-family:仿宋\" displayFormat=\"YYYY年MM月DD日\"\n            [(ngModel)]=\"sign.signDateA\" readonly class=\"datetime\"></ion-datetime>\n        </span>\n      </p>\n      <p style=\"width:47%;font-size:14px;line-height:150%;margin:0px;widows:0;float: right;background-image: url() \">\n        <span style=\"font-family:仿宋; font-size:14px\">乙方：（盖章）</span><br>\n        <img [src]=\"sign.signatureImageB\"/><br>\n        <span style=\"font-family:仿宋; font-size:14px;\">乙方代表：</span><br>\n        <!-- <ion-button (click)=\"toSignB()\" *ngIf=\"!sign.signatureImageB\" color=\"danger\" size=\"small\">\n          点击签名\n        </ion-button> -->\n        <span style=\"font-family:仿宋; font-size:14px\">中国移动通信集浙江有限公司宁波分公司</span><br>\n        <span style=\"font-family:仿宋; font-size:14px\">\n          <ion-datetime style=\"padding-left: 0px;font-family:仿宋\" displayFormat=\"YYYY年MM月DD日\"\n            [(ngModel)]=\"sign.signDateB\" readonly class=\"datetime\"></ion-datetime>\n        </span>\n      </p>\n      <p style=\"font-size:14px; line-height:130%; margin:0px; orphans:0; text-align:justify; widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">&#xa0;</span>\n      </p>\n      <p style=\"font-size:14px; line-height:130%; margin:0px; orphans:0; text-align:justify; widows:0\">\n        <span style=\"font-family:仿宋; font-size:14px; font-weight:bold\">&#xa0;</span>\n      </p>\n    </div>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/sign-page/sign-page.module.ts":
/*!***********************************************!*\
  !*** ./src/app/sign-page/sign-page.module.ts ***!
  \***********************************************/
/*! exports provided: SignPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignPagePageModule", function() { return SignPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _sign_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sign-page.page */ "./src/app/sign-page/sign-page.page.ts");







const routes = [
    {
        path: '',
        component: _sign_page_page__WEBPACK_IMPORTED_MODULE_6__["SignPagePage"]
    }
];
let SignPagePageModule = class SignPagePageModule {
};
SignPagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_sign_page_page__WEBPACK_IMPORTED_MODULE_6__["SignPagePage"],],
        entryComponents: [] //引入组件
    })
], SignPagePageModule);



/***/ }),

/***/ "./src/app/sign-page/sign-page.page.scss":
/*!***********************************************!*\
  !*** ./src/app/sign-page/sign-page.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#datetime {\n  --padding-start:0px;\n  --padding-end:0px;\n}\n\np {\n  line-height: 150%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2lnbi1wYWdlL0M6XFxpb25pY1xcY2FydFxcY2FydFZpZXcvc3JjXFxhcHBcXHNpZ24tcGFnZVxcc2lnbi1wYWdlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvc2lnbi1wYWdlL3NpZ24tcGFnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBQTtFQUNBLGlCQUFBO0FDQ0o7O0FER0E7RUFDSSxpQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvc2lnbi1wYWdlL3NpZ24tcGFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjZGF0ZXRpbWV7XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6MHB4O1xyXG4gICAgLS1wYWRkaW5nLWVuZDowcHg7XHJcbiAgICBcclxufVxyXG5cclxucHtcclxuICAgIGxpbmUtaGVpZ2h0OiAxNTAlO1xyXG59IiwiI2RhdGV0aW1lIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OjBweDtcbiAgLS1wYWRkaW5nLWVuZDowcHg7XG59XG5cbnAge1xuICBsaW5lLWhlaWdodDogMTUwJTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/sign-page/sign-page.page.ts":
/*!*********************************************!*\
  !*** ./src/app/sign-page/sign-page.page.ts ***!
  \*********************************************/
/*! exports provided: SignPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignPagePage", function() { return SignPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/http.service */ "./src/app/services/http.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





let SignPagePage = class SignPagePage {
    constructor(http, storage, nav) {
        this.http = http;
        this.storage = storage;
        this.nav = nav;
        this.token = '';
        this.gname = '';
        this.cname = '';
        this.gid = '';
        this.cid = '';
        this.mid = '';
        this.sign = {
            mid: '',
            gid: '',
            gname: '',
            cid: '',
            cname: '',
            aPlanNum: '',
            bPlanNum: '',
            cPlanNum: '',
            planStartDate: '',
            planEndDate: '',
            signDateA: '',
            signDateB: '',
            signatureImageA: '',
            signatureImageB: 'data:image/gif;base64,R0lGODlhlwCXAPcAAP////8AAP+qqv/i4v9VVf8cHP9xcf84OP/Gxv/7////+/+Njf8GAP9oaP+env8ABv/m5v8GBv93d//7+//MzP/2///u9v/z8/8AC/93kf8GEP8LAP/avf/78v8QBv/y+/8UC/8LBv8GC/+Fnv/2+/+9nv8iPP8LFP+Rqv//9v+qkf+gvP/79v8eEP8QGP8QC/+DoP+DZ/9ERP/27v8fC/9RUf+McP/u7v+Rkf8YKf/u+//l7v/l4f8iAP/l8v/Q1P+skf9JSf8YEP9YO/9LZ//28v92V/97lf/u2P8UJ/8LGv8wE/9mhP8UIv9nS//W6f8yS//S5f/l2v+sy/8GFv9hYf9NTf8WBv/u5f92kf+3mf+tkP9YdP+QdP+wsP/77v90WP8AE//z//+Xsf/YvP/ayf//5v9iRP+tyf+ehf+qzP/u2v+2mf/l0v/y8v+kiP9EKv/y9v8WEf+mpv8REf9Xdv/u8v/y4f/L5v/d3f8RDP9Ya/94a/+kwP8eFP/y6f/l9v/l1v/u//9JMP+ojP+Zf//75v+Emf/q9v9rT/9AJv/hxf/F1v9QUP/y7v+7wP9JaP8eLv/FqP+mnf87WP+lwP/y2f9QMv8vEf8GIf/O3v9ESP8RAP+dnf/e7v9ISP/y5f9IRP9IL/8RBv+Enf/y6v9mZv8GG///8v/q4f/y//8pGP/Hpv8hJv/SwP/S2v8QGv+RrP8hIf/ApP8UHv9EYv/azv8YFP9mSP8eMv+8oP9ng//A0v83SP9IZv+gg//J2v90kP87J//24f8uS//39//h6v83VP8uGP/N5f9ARP8GDP/m4v9hgP9XW//ix/8mC/8qEf+8yf88Vf+Vlf9bW//Jsf9ndP/FrP97XP/p8v9TcP8nFP8uQP8YLv9AV//a6f8uFv+du/+Zt/83Iv+XeP8QHv/SvP/d1P9thP83QP/Q0P+7u/+RjP9wjP9EQP9IUf/79/88V//h2P+okf/Zu/9TRP8mJv9RV/8mKv/m+//Q6v8WJv8vSP/h4f8RGiH5BAAAAAAALAAAAACXAJcAAAj/AAEIHEiwoMGDCBMqXGgQgYCHDxEwnEixosWLGDMufEiAQIEAIEOKHFmg40ONKFOqXLnRwIGRMGPKDHnAgACWOHPqNCjA5cyfQGPWvLmzqFGKAl4GXcp05AGiR6MeRUCgqdCOWJVaFUlAotSvKgcY+MjUpIABBlkkODiAY1WmBQygBUuXotilJc8qvAFg2LQdDNt6XCq3rmG2BoDmncuQDSlUnBhZFEx2ZuHDhge8nUkAasVCD3hhwqNRwGaZBBhjjpp45oEFKLM1+XBpDMNzXuIgXKA1poHVUyvDvJwQwsIh8gAYacZw1r0Iyha8Euj5rswCXoGz1GxZdZ6DCpA9/0moIFoWAGm6USzixZSfkg8AFbQeM7V2lQu6Gyz0lyC6LgF0s9ZBlgQwBQD1YCCfRbbYo4EmiM0E230YDdCbSL8hlIIwOWiDAB+rYNAAGhMkNAsGOgDwBScrYDTINgu1BtMBqlG4kXA01WiQKww440I6XTwwnkIxQDHQJUQkNAkvBUEwDAMtLmRhTAV4ZiNCMopUwIQArAEYQk4ocwwAoGwAw0JwHAJAib9osKBBYBRwSxUCWPAGE1ooSNECOIKU4ZUGTQmTfQOxQQuTBwUyRxNrDUGJQsNEkAwADSSABANHKDQPNaFEEEAtiRAz0RwCcTejjjYO0GcAVgIAYC0DEv+EwFrkeALAG3oitIWokJ15hhK2GsRDrCx4sQANmS4EygmqDCQAlahqh0CfBcxVSBW8uIKAIrUg1MU02uBy4KVRHjSEbc8E4A4A1gTQiwUG2TCOQH98AAAZAZB2EDskCLRFAMGWSm12FD47KEFrgFBLGRso4YOGwpjAR7JwJHkQEpFUAAAQAQx5CR3SGATHCc7MMUQfANjgTawEYfPPwwDAQUWzBZ0WUquYGTwSUWzg0wki/44DIBoJlcHAPb4I1MUpGhvUhW0AZJPLQGVUYtCTh1BjTwBMAKAIFwe5AkIOIbebDkI6i4RzXWnfPJACMQTgjQVOnPBIAUnAawgKcOb/Y4JA6RJtEAUDKlLHQnnKl6cPl6JckDUgQDEJCNfYcGZCbYO09leZY2cQPQz0Qk0LsoAEYwpX4PMlvZOE0awC4Rye0JOVOMJyQaEKlPsWYaSI8AYujIeFPbRYrdC0MG1+VOfRsrHJP2kE4IIpAawwywZ72FGQAjToG8PKJlKhAyGxaIgsACmcf8ajBClQxAIQFurHHgI0kJCqyRuGAEzVLgQGA3TQQBSGEIF/BOByBRGFOATSLkQdJBtJQsJsDoIv0lQQdQgEnAkkUxBQnIFrCsHfSAgWFRGGpH8LQcIGpMENKKzBA0SIAQaAYRBcnAd9NAhGQpYQJThkcCA2eIAp/7zwvQS0ax8FwQIf6JAOew3EFn4IQPlCiCMUlrCK0RrIM/AhgERswxoMOAQNAjAGcpigaQOJQbcEAoa/HeQZ4lPaBAtCjm+04x0BAFsMpnYQKbwjEiFjlxyukYcSSQmLUrmQFRXyBga8IDRxm8YQzOEFBugwjavwxkB00bGD2ABsAuEAGQtyKavdAUoAIAdzEAKKK+TRAjFQj0LW8I2BmBAkB2ANTBAwAxyYgoYKsYYHAnCMDpAjEujwABe6gAEHukIUDwjWF65wJlRcYyBYaAE+JMDNBWxgjQORQhQEgg1TIAIJARDcQZygAWnYgw4MSJpCziBPgexvJH/SSeZ45v+BHMQvIdZohQfQgIsABKMcoRFGLpwIgDtsYF4CGYKR0kWKUIYEOtcQhiYX8oY4HoSTl2ODH26IEEIEIFnOyp9ObskqgpRhFRpokTVkQYTbCSQGJiDHPTAgDWQQg2G7IAiSBrIFDJjiFq1Ix1oUAI09PMKQMcgEQ4ZQy4OAogVQiFUpplMQXUjGFRtIAswA8AeNtW2RK7kQAQzyhyGoawaurEO/CnKHYe5BoZxEA2gCCYAYnAICkyBACNQhnYKsoyBAYN/F8MGDK/BtnQJcyB1AgEQbWEGdUiCHPgRis1ziJD9aKkgMTCGAYsTtH9MoROhWl8YTxAKooiCGAgaRN4H/aAEk3UABXybSAXAkxJgPwEDACAJShpwhCQlQAD2EsC4AnOMWABsIjriUkgHApEbtkl0iApCLJ8wCBE3g4EDWsIFMgUYCAeBFG5QpkDIpFie/CMAqCzKDFghoIdHbhTWEAZLzsCEEkRAvAKw7kixWxGatMkI3NOaKCDjADy7ghS1gWi4AtOEKJ/DEbJOADLDF13HWYMdOdHENNK6JjTNcSBs20AQ8gqQRJ+BDAL4Br4K0ba0puWdIcEyQNzQhWAogwAIEIAwNVOIPgwgASa2Rj09Z2AMhUEIFFDDJ4X5lEMCQhEEZsoZ3MCAfengACoyZR5tydoQpEQ5ai2CPKQqk/xBcm0EoHjAOFoAhAL5gKMdsE98ASGYNcphUXS4RCSGcETxLpYcfWiGBW7hAGqmAwwMO0ItOPHY+akZJlgJA3YSc4RtrYcEHqQEA1XZjdUM4gQBWAZIp2uIwH3TBPwvihBVggxwiyAA9QpCDJ5TBDydAwzlCUL3d4DMjBKbJRACEj0AqwAlSBMAs+hk/fE2DHU6QBUoN0wEawGNIByGHp+DximwEYBknWIAHIrGOUAQgHwtOyIUMjBCb0VvaMQ5APyAAmGc/AGW/jjAbo22LR6xGAYZESPRosYIykOMB1ZCDM9yljS/kJjAj4bFdjs0QG/AtbtcQQiQMwA4HQUgKyP/QgGQ68DRAGQQL0J7GAAoRAn54ARnrMkI+agDMiWz63gTZ9EWo/CBqsFoO3LXXGmiQBIa6vGUtCEA62PHwa9xgEKBOxZ1zYeaEcHwiyfYTRmZAjqyyYLsg2cU5khwAxz19IA59gDPw2AvJfM8fEgiBCCQgYJ8XmCI/J0g8brBbhbQBBDDoADdQwIedMgIHEnjHCN5OkHQFQATOQNQ5GGAFEIjgGqytSNgDkM/7fV0gHGuCbxGnhLjp6xKyA0AxctKRnGCD5BOYADomAQYhBKAAGQg9Q6RgcIEEPkZ/n8c7GdFtWfTauCDZ7L2U4DudeISEKcnGCy7aZFJ03SAdYEf/OwgQReMN+PQIEc6fKIAMF0jgGFgQRhO4WrR7BOBNlziQPjWnEwXMgwKFNAT8YGJP1AkOQA0SUAWfUDogwQ81cE2usHpZUgALoWMgoRozAG27MAld4AFNAG48gAB8NRAIYAyFsm0sYTCeVRSiFFR95AB8IAub0AhVIAEOIA1uIBCpkAgeNXrYRxCn4VkKAAZBMHlpwAAHsH0BYAIC0A7SYAu+d2l1IRJHETcLRB7hYH5v8wYv4FQE0RsaZxAjwSWc1DUAgA2yAA4I4AUhEgJJsAPkIANSdxgi0Wk4oQjptRCEYCQEIQWX0AQjKBCgFRKYMxIEkT6wIAEmCAS9wA4W/2ALHmAAQtAKXAc6RECAR3EaYcgSCsAHVTBrBMECpuEp4oUNIPAN2nMQO4MQYFgQuCADBSB3XuAHTaAxW2ACZXALuQAvsxACtYCJOyEoIOE5RaEABoEOWkNsuZABfAAj6MEAu/B9QYgQq0gQNjAGEzAJL7EMvjBXQ4AH6HALB2AFViADDBB7y6NSOtFlB1ADHXEAoxAADxAd8dMGIuCO8rURhsgToVUQthAwswASsFAFwsAA/IACUNgABKCEWlgUmwYSR4EFArAABiABnfAIcwUAz8AHShgAWcUQwtEqWbKJBVEOtWANrHZ5+ZAP0uAKreADE5AHZ+ANwIgTMvEVPP/QPl6AR7DgDhRAAxgwTgxxGqUHAL2hPK7SIiwQAwygBwGCjVpwNgCgQm63ExbIFVGxCGGgMTwgAR/RDWPQL+VATEghEis4EH9XERRwAMrgbrTgDvSXCGZYFDazY0fRAUkWeZe3Bw4kEDPQlyG0jyl1QhixlCbgBRwpd0wyCxYTjBeiNkZhBCGhDp1QY2kGmQMxkhphDfdQCUXQDqzWDe3gjDuROZhZFFJAAanIEkT5haeJEVjwDgukANjwDifQdzjxkIJJefyobGgpEmhRBIVwDY+QBxnJEApQfAJhC5apE0GhHd8xGbu5jygpEicwjjXoAF7wA6u5GkFBkl8xAw3/0ArO0Ak/8H0EIZhpw2M2kAW2AAYRcAgJaAUH4JQgEQGyIAPOYADUIAAI4A+zFxWDyBlfYYwHMQP0YA8hEAE71wAL0Alz8BAjeBpEsZ4DkQixAHMPIH2lMAk18AR5wA5z0A4GYAUhoAcMEBLJkYlLgZQowQ4EcALXwA45eBATgACdYAqhIAspGgD/IJRn5jYAQKFHciCGkAkD4kcYIAjnIAoBwA/4AAIGYmGn4AWdUH06gTxB4aIawQYg4QxN1grwcA2dwA55EKAGcQOz8AoT8AODCRI4RqQCQQ6k8QwPoA41UAUL8AaZYAMvsAkW+YRXQBqL4EYKARGImqiKiqi6/ykUi/qoinqWB3FnByKRfBAK8XiftzB5A1EsfHAAmPKmAYBjwjEXCtADm8UKkSAB1RAK+UBsILEM+bAJ1SABo5CqK6oQg7EVvNqrv2eHBXEOo1QQPIAN1PAOagIALDAJ9hAB/GAAXoAADBV2FAgAgmkIp7AWQNCY0jYNIToHC9AANSAM2QoAhECax+Or6toUP7g94YBS2OAMYyUQUsCRIrAHgZieVGit++pc5lCcXXBNA/EG/WAQz8BHNtBcEzGg69qwO9auBhEDzVAE1HAP3UB/AFAKfMAAsHAE2rAQ+7iPtmB/IXGdVlCDEiAAP1B4AMAKsmQEUsgQjeqwvFqUCf8xA13AD3rnDsepC1F3Dc3pdfu6mwBwA2XgBZMwn/V5UbKgDM5gD0ngn4OgBhjxmDTbFK9BEQqwNQEQAXsApAJxDo8ENRNhiBYoqQkRD99KojXwDsJxC+oEdjN7ta4BdE80B14QtAPhCjG7EL3hEFipEjfgEDjAqRbBsHT7E11hIxRqoTaSFIkLFDa7Go0buFditZGLtvdRuXYJKG0RuU5ht3TBuXBqEROwDp0gATWpElQBusTIEjNgD6bQCdLgdBZBoWe7EBPgCp1QBQfgKSKwCXG7E3PbqxCrEfQQCrDaCjUgAXPwAyVSBjWlEH/Lr4TYR6twCylKB4AqAGxgqAX/kQp5yxK8QbPAihOYIA3GUg0FKQLexwoFqxAh268FUQjvwA8C4A8EgQp04DviKwH2gHQBorfIhrlNMbksYQgaQDMCYQTJmgaxdwfIoC+/eb1ESxCWgKQF4Q/RsAdBIMBNAA8S4AUmiBOmuRVcWhHYYHAdsAoH8A8XWaOioH9GUFECga0EOL/XixCYsA95IAB88Al0ABK0gA8L4AXdqRPFuxSaixEp0AlVgSjl9AkCzA/w4AFRIgoOVA/xq6/XW6rHOAl8IAQ9mg/OsADsUA7oeBRXixNxQwXUwAvHWQriRwAR8A07wD3SdytrTK1Byn8CwQZ04Cnvlg/T8Ai6MRD1/yBLUXGV6gqeGKEL9pCp94APGeAF0Sl7AtEG8jVXNWxjgSunoPAOznAIj2AvJZCrAjEP9IABoRAM6JkSdemrkKwRPLC+5HCf6lAFZeoGsyAD6cBVMwzKneu4BJIJ6zAJBvAOxBYBB7AH1GBlOCGMDpvCGXG6YkzFIBHCzvsD8UADVianxmwQm9e16tAADrAOCZeOdGvNK+EI4lcNvwsSD+AOifzHLSUQFzwQ7WCesVyakasdCoAO9GAFXsAy0wmcb2fAGLLEEPl2o+eaQupyQZG1AsHQpft0aXOWmulyiBu6BEHN9fF2rSmq1QooszyM4KmlMuHOXxGSBZGWNsLSu/90PDPr0iV0wUcJKCeMwAXRqD59GBttEB1tI1ZLI3Zxwi5X0gSRNidNIfxzvAhB0xltIzAthq8JHANaElKdEAjAJ5Z7H23DimENHKfR1QyBADLyutoxjQcx1mL9sDkxiDi9E9WoinUY16RXFJDbxHXBsLpqlvcRAH7NEi9BIa3o1TKdM6KLbHU9zWimEOrHm5SNERMos4td2ZqNEKMX1OeHIZsd2liS2aOt0DmBBRTwFcxwzwLRAcp5Gw2ZE529caCdE6wQAHtwnBlhDSg4EHDwLgTRLgq7EGZjFMfnd/S7Eu0CTgkhBQ7w3NAd3Z0QdfpHECtSbAMBZ9Owuu0DDUv/Sk6GqxLoJyXjjRKilAEM0QHZGd3QjXZjUhBatqLWQDRn8ABIBABsAFED4QgQ0N/9rVD9jQ4t8AC4admkvRD2hhPnnRKHpwEoYFN3dggUADnmsAM00A0UQAFe4AGRNRDnwL1+oAwNMOLUgw8j3rcXMXq1zNlOoREKwA6xsuADQQ/zuhBk9w8F3m1NAAKAyk3Rgw/CkA/cNMIHUQ6yJhCLECD/PBHzlhGbdr4M0QPTAN02EAD4AN0yxq0KQWU5cN8GcVuxEAMnIJTf8wFadoUIgU5u9AYBoN8pwbCenRBq1tgD0QP4+xBwRgQQcWegthBlgAA2kAOrdxCXcEZaRgRF/8AM4WAbqKMEiKAQmKDBQwBO9IDiYJdpKHGVK44QPWCoMg4AKhAAlk4QKhABH5gQSW41BeINcPaRAOBWVDsQbuDf/Y0kEDAPICAN/W0NG9DhF2EzaB3YWT0RnT4Qnx7qoz4Qoa4Bg24QTsA+p/oNyECWAmEDGjBcbXAPMmAKI97t3u7tpHIRN7YSoxcAdL4Enh4A6C0QyN4Y6l4Qjgg4dBAwCBA9clNjqYCxBMEDLEsQFCB8tG3a+EESF4Huxv7u7C7qDFECARDeWuaMrjCCilc9Q7AJ3O0qTRChiToJG9ANtksR05UTamURS/ACMnDy/JWfJ29/UvgG3z7i7tYN3v/ue9hdEObWNQmzCR9PEHB2DTjw80DfDgEQCR/76y0u2zhizQZvUesO6go/EOjgAD9A6xDwLxlA9f3d7xsTANtNTgzQDWBbENET6wRhBgEACRhxVnTOEPtEEUsPAMf+9ArB8OGdECWwAcDNQL73eWEvEGNvEGaP9hbR9g5Z0wzx9nGf7AJB9wwBBAywDFXg7VHUDVI69NXwJugRIEGw+ZzvboJPEY4c5xqhSPcGDene9O2+EIz/W9mgATAQCNTwCBk++z8QCJcQACcAmH9fEIEvejhS2OSOSArR6RdQ/MIaDMV/AWyu+ACw+mFzD3sADo4we6CwCTCzIQbnBSIm9gH/QPYDYfbTYBfCf0UkYWA9cAJYgUf5kBUNv/DtjxDoEJ0xUFWKUFVJrnIIMZYH0AiNIAv/ABDwGtkLMA3AQYQJEQ4oEMChwwIDFE6kWNHiQQQPH0a02MMEQg4BMiBkY+IHH0EXSwQYcREhmQCxANgIgAYAoQB7ElTski/KwUFhxAD4Ak+aSwAMNTpEgNTpUwFLA3CcmGLVIZAiFX7ZoE8lS6cKoilBtJIIgEQP8DwNOhShrpYVlS4V8NQu0qhLCzR1GXJkQjMBAH2Ni/RMABjPAnhTAO0bRR4UJE+mIAwDgslePDzgRRFBQ7p3RV/MG/qiX4XDAqy1uLKwy0IBmhli/2AC5hSKZQ44k9C7N7cHvoWPmVhaY93RySkaf4i8IuqESAIcocjMx02wTiUFIJ5ojI1+CAs9ctkWr9QAzpWvR8jcIQGLiwrauVD/gooALlIqLPRiWYjsKirCvlQcoK8+ZMaoD6ckLLjIvIsIQE899ir8TCqqtmoBvQCOqSgQZAJ4IJmLwBBBGQJSVHHFFSu5CA6hLJpLo70qtDGhGY+jKBAHevTRAS9IsGiWB1678SJyItivOPQyPNLGAQ5AjwCJKpygmCedYscYigaQUKoDqszySAOaXGBMNJ9aALSlDEgzSwHY1CjMN+vEUUoMKbSTvSg5dHPPNMtEj05An1yAw7gADBCz0PUGEBS9MxnN0ktEFZV0NEcRpfJSNC/0c1FO5XoUQ75CRXNUMCM1NaEF8PRz1TopRTQAAvQsVIAvNQUVVjQznbWAWncdcwBc5UTPUl4L9XXWqYJ9klgCjP00WU4dlVbTWgUQVi4BcM2V2amQpdZUBL4FF0wWXT1XKgJKHTdZAdRdd15wD7D1XWoFMEBeeuk9wIB78RUYAH357RdMgAdWGCpvr+UQ2GwXlthGBLq12N2JXQoIADs=',
        };
        this.token = localStorage.getItem('token');
        this.sign.signDateA = new Date().toISOString();
        this.sign.signDateB = new Date().toISOString();
        //this.sign.signatureImage = this.storage.get('signatureImage');
    }
    ionViewWillEnter() {
        console.log('进入了');
        this.gid = this.storage.get("gid");
        this.cid = this.storage.get("cid");
        this.mid = this.storage.get("mid");
        this.sign.signatureImageA = this.storage.get('signatureImageA');
        this.initName();
        //console.log(this.sign.signatureImageA);
    }
    ngOnInit() {
    }
    initName() {
        this.http.ajaxGet("/market/company/getCompanyById?id=" + this.gid + "&token=" + this.token).then((response) => {
            console.log(response);
            if (response.status == 200) {
                this.gname = response.data.gname;
            }
            else if (response.status == -1) {
                alert(response.msg);
                this.goToLogin();
            }
            else {
                alert(response.msg);
            }
        });
        this.http.ajaxGet("/market/cust/getCustById?id=" + this.cid + "&token=" + this.token).then((response) => {
            console.log(response);
            if (response.status == 200) {
                this.cname = response.data.cname;
            }
            else if (response.status == -1) {
                alert(response.msg);
                this.goToLogin();
            }
            else {
                alert(response.msg);
            }
        });
    }
    back() {
        this.nav.navigateBack('/tabs/tab2');
    }
    toSignA() {
        this.nav.navigateForward('/sign-pad');
        this.storage.set('signImageFlag', 'signatureImageA');
    }
    /*  toSignB() {
       this.nav.navigateForward('/sign-pad');
       this.storage.set('signImageFlag', 'signatureImageB');
     } */
    doSign() {
        this.checkLogin();
        //补充字段
        this.sign.cid = this.cid;
        this.sign.cname = this.cname;
        this.sign.gid = this.gid;
        this.sign.gname = this.gname;
        this.sign.mid = this.mid;
        console.log(this.sign);
        this.http.ajaxPost('/market/sign/doSign', this.sign).then((response) => {
            console.log(response);
            if (response.status == 200) {
                alert('协议签订成功');
                this.nav.navigateRoot('/tabs/tab2');
            }
            else if (response.status == -1) {
                alert(response.msg);
                this.goToLogin();
            }
            else {
                alert('协议签订失败');
            }
        });
        //清除localStorage
        this.storage.remove('signImageFlag');
        this.storage.remove('signatureImageA');
        //this.storage.remove('signatureImageB');
    }
    checkLogin() {
        this.http.ajaxGet('/market/sso/checkJwt?token=' + this.token).then((response) => {
            console.log(response);
            if (response.data == 200) {
                console.log('token有效');
            }
            else {
                this.goToLogin();
            }
        });
    }
    goToLogin() {
        //localStorage.setItem('redirect', location.href);
        //window.location.href = 'http://localhost:8200/tabs/tab1?order=checkLogin&redirect=' + window.location.origin + '/redirect';
        this.nav.navigateForward('/login');
    }
};
SignPagePage.ctorParameters = () => [
    { type: _services_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] }
];
SignPagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-sign-page',
        template: __webpack_require__(/*! raw-loader!./sign-page.page.html */ "./node_modules/raw-loader/index.js!./src/app/sign-page/sign-page.page.html"),
        styles: [__webpack_require__(/*! ./sign-page.page.scss */ "./src/app/sign-page/sign-page.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"], _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])
], SignPagePage);



/***/ })

}]);
//# sourceMappingURL=sign-page-sign-page-module-es2015.js.map