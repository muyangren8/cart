create trigger FLOW_USER_TGR
    before insert
    on FLOW_USER
    for each row
BEGIN
SELECT FLOW_USER_SEQ.NextVAl INTO :new.ID FROM dual;
END;
/

