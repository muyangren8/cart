create trigger HISTORY_ID
    before insert
    on SMS_MT_HISTORY
    for each row
BEGIN
SELECT emp_sequence_history.NextVAl INTO :new.ID FROM dual;
END;
/

