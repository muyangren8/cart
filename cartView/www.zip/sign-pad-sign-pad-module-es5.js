(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sign-pad-sign-pad-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/sign-pad/sign-pad.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/sign-pad/sign-pad.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n  <div style=\"border: 1px solid #000000\">\n    <signature-pad [options]=\"signaturePadOptions\" (onBeginEvent)=\"drawStart()\" id=\"signatureCanvas\"\n      style=\"padding-left: 5px;padding-top: 3px\">\n    </signature-pad>\n  </div>\n\n\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"4\">\n        <ion-button expand='full' color=\"danger\" (click)=\"drawCancel()\">取消</ion-button>\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-button expand='full' color=\"light\" (click)=\"clear()\">清除</ion-button>\n      </ion-col>\n      <ion-col size=\"4\">\n        <ion-button expand='full' color=\"secondary\" (click)=\"drawComplete()\">确认</ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>"

/***/ }),

/***/ "./src/app/sign-pad/sign-pad.module.ts":
/*!*********************************************!*\
  !*** ./src/app/sign-pad/sign-pad.module.ts ***!
  \*********************************************/
/*! exports provided: SignPadPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignPadPageModule", function() { return SignPadPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _sign_pad_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sign-pad.page */ "./src/app/sign-pad/sign-pad.page.ts");
/* harmony import */ var angular2_signaturepad__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular2-signaturepad */ "./node_modules/angular2-signaturepad/index.js");
/* harmony import */ var angular2_signaturepad__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(angular2_signaturepad__WEBPACK_IMPORTED_MODULE_7__);








var routes = [
    {
        path: '',
        component: _sign_pad_page__WEBPACK_IMPORTED_MODULE_6__["SignPadPage"]
    }
];
var SignPadPageModule = /** @class */ (function () {
    function SignPadPageModule() {
    }
    SignPadPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                angular2_signaturepad__WEBPACK_IMPORTED_MODULE_7__["SignaturePadModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_sign_pad_page__WEBPACK_IMPORTED_MODULE_6__["SignPadPage"]]
        })
    ], SignPadPageModule);
    return SignPadPageModule;
}());



/***/ }),

/***/ "./src/app/sign-pad/sign-pad.page.scss":
/*!*********************************************!*\
  !*** ./src/app/sign-pad/sign-pad.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NpZ24tcGFkL3NpZ24tcGFkLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/sign-pad/sign-pad.page.ts":
/*!*******************************************!*\
  !*** ./src/app/sign-pad/sign-pad.page.ts ***!
  \*******************************************/
/*! exports provided: SignPadPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignPadPage", function() { return SignPadPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var angular2_signaturepad_signature_pad__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! angular2-signaturepad/signature-pad */ "./node_modules/angular2-signaturepad/signature-pad.js");
/* harmony import */ var angular2_signaturepad_signature_pad__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(angular2_signaturepad_signature_pad__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/storage.service */ "./src/app/services/storage.service.ts");





var SignPadPage = /** @class */ (function () {
    function SignPadPage(nav, storage) {
        this.nav = nav;
        this.storage = storage;
        this.signImage = '';
        this.signaturePadOptions = {
            'maxWidth': 1,
            'minWidth': 1,
            'canvasWidth': 400,
            'canvasHeight': 300,
        };
    }
    SignPadPage.prototype.ionViewWillEnter = function () {
        console.log('进入了Sign-Pad');
        this.signImage = this.storage.get('signImageFlag');
    };
    SignPadPage.prototype.drawStart = function () {
        console.log('drawStart');
    };
    SignPadPage.prototype.drawComplete = function () {
        console.log(this.signaturePad.toDataURL());
        this.storage.set(this.signImage, this.signaturePad.toDataURL());
        this.nav.navigateRoot('/sign-page');
        this.signaturePad.clear;
    };
    SignPadPage.prototype.clear = function () {
        this.storage.remove(this.signImage);
        this.signaturePad.clear();
    };
    SignPadPage.prototype.drawCancel = function () {
        this.signaturePad.clear();
        this.nav.navigateRoot('/sign-page');
    };
    SignPadPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
        { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(angular2_signaturepad_signature_pad__WEBPACK_IMPORTED_MODULE_2__["SignaturePad"], { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", angular2_signaturepad_signature_pad__WEBPACK_IMPORTED_MODULE_2__["SignaturePad"])
    ], SignPadPage.prototype, "signaturePad", void 0);
    SignPadPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sign-pad',
            template: __webpack_require__(/*! raw-loader!./sign-pad.page.html */ "./node_modules/raw-loader/index.js!./src/app/sign-pad/sign-pad.page.html"),
            styles: [__webpack_require__(/*! ./sign-pad.page.scss */ "./src/app/sign-pad/sign-pad.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"]])
    ], SignPadPage);
    return SignPadPage;
}());



/***/ })

}]);
//# sourceMappingURL=sign-pad-sign-pad-module-es5.js.map