create FUNCTION checkIMEI(imei IN VARCHAR2)
  RETURN int AS
v_last15   varchar2(100);
v_imei22     int;
v_imei24     int;
v_imei26     int;
v_imei28     int;
v_imei210    int;
v_imei212    int;
v_imei214    int;
v_imei_valid   int;
v_flag   int;
BEGIN
/*
IMEI校验码算法：
(1).将偶数位数字分别乘以
2，分别计算个位数和十位数之和
(2).将奇数位数字相加，再加上上一步算得的值
(3).如果得出的数个位是0则校验位为0，否则为10减去个位数 如：35 89 01 80 69 72 41
搜索偶数位乘以2得到5*2=10 9*2=18 1*2=02 0*2=00 9*2=18 2*2=04 1*2=02,
计算奇数位数字之和和偶数位个位十位之和，
得到 3+(1+0)+8+(1+8)+0+(0+2)+8+(0+0)+6+(1+8)+7+(0+4)+4+(0+2)=63 => 校验位 10-3 = 7
*/
 select substr(imei,15,1) into v_last15  from dual;

 select  substr(imei,2,1)*2 ,substr(imei,4,1)*2, substr(imei,6,1)*2 ,
    substr(imei,8,1)*2 ,  substr(imei,10,1)*2,
    substr(imei,12,1)*2 , substr(imei,14,1)*2
   into v_imei22 ,v_imei24,v_imei26,v_imei28,v_imei210,v_imei212,v_imei214
  from dual;

 select case when mod(( substr(imei,1,1)+trunc(v_imei22/10)+mod(v_imei22,10)+substr(imei,3,1)+trunc(v_imei24/10)+mod(v_imei24,10)+
   substr(imei,5,1)+trunc(v_imei26/10)+mod(v_imei26,10)+substr(imei,7,1)+trunc(v_imei28/10)+mod(v_imei28,10)+
   substr(imei,9,1)+trunc(v_imei210/10)+mod(v_imei210,10)+substr(imei,11,1)+trunc(v_imei212/10)+mod(v_imei212,10)+
   substr(imei,13,1)+trunc(v_imei214/10)+mod(v_imei214,10) ),10)>0  then 10-mod(( substr(imei,1,1)+trunc(v_imei22/10)+mod(v_imei22,10)+substr(imei,3,1)+trunc(v_imei24/10)+mod(v_imei24,10)+
   substr(imei,5,1)+trunc(v_imei26/10)+mod(v_imei26,10)+substr(imei,7,1)+trunc(v_imei28/10)+mod(v_imei28,10)+
   substr(imei,9,1)+trunc(v_imei210/10)+mod(v_imei210,10)+substr(imei,11,1)+trunc(v_imei212/10)+mod(v_imei212,10)+
   substr(imei,13,1)+trunc(v_imei214/10)+mod(v_imei214,10) ),10)  else 0
   end into v_imei_valid from dual;

  if(v_imei_valid=to_number(v_last15) ) then
           v_flag:=1;
     else
           v_flag:=0;
  end if;

  RETURN(v_flag);
END;
/

