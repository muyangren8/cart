create trigger AUTO_ID
    before insert
    on SMS_MT
    for each row
BEGIN
SELECT emp_sequence.NextVAl INTO :new.ID FROM dual;
END;
/

