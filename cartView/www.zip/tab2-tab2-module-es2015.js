(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab2-tab2-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/tab2/tab2.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/tab2/tab2.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"light\">\n    <ion-title>\n      集团签约\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <ion-item color=\"light\">\n    <ion-label>选择集团</ion-label>\n    <ion-select [(ngModel)]=\"gid\" (ionChange)=\"initCust()\" placeholder=\"请选择\" cancelText=\"取消\" okText=\"确认\">\n      <ion-select-option *ngFor=\"let company of companys\" [value]=\"company.id\">{{company.gname}}</ion-select-option>\n    </ion-select>\n  </ion-item>\n  <br>\n  <ion-list>\n    <ion-list-header color=\"danger\">\n      <h4>客户列表</h4>\n    </ion-list-header>\n    <br>\n    <ion-item *ngFor=\"let cust of custs\" color=\"light\">\n      <!-- <ion-label>{{item.title}}</ion-label> -->\n      <ion-label>{{cust.cname+'  '+cust.phone}}</ion-label>\n      <ion-button (click)=\"toSign(cust.id)\" slot=\"end\" color=\"danger\" *ngIf=\"cust.status==0\">\n        签约\n      </ion-button>\n      <ion-button (click)=\"toView(cust.id)\" slot=\"end\" color=\"success\" *ngIf=\"cust.status==1\">\n        查看\n      </ion-button>\n    </ion-item>\n  </ion-list>\n  <!-- <ion-list lines=\"none\">\n    <ion-item>\n      <ion-label>选择客户</ion-label>\n      <ion-select [(ngModel)]=\"cid\" (ionChange)=\"hasCid()\" placeholder=\"请选择\" cancelText=\"取消\" okText=\"确认\" >\n        <ion-select-option *ngFor=\"let cust of custs\" [value]=\"cust.id\">{{cust.phone}}</ion-select-option>\n      </ion-select>\n    </ion-item>\n  </ion-list>\n  <ion-button (click)=\"toSign()\" expand=\"block\" color=\"danger\" class=\"sign_btn\" disabled=\"true\" #signBtn>\n    进行签约\n  </ion-button> -->\n</ion-content>"

/***/ }),

/***/ "./src/app/tab2/tab2.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.module.ts ***!
  \*************************************/
/*! exports provided: Tab2PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab2PageModule", function() { return Tab2PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab2.page */ "./src/app/tab2/tab2.page.ts");







let Tab2PageModule = class Tab2PageModule {
};
Tab2PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab2_page__WEBPACK_IMPORTED_MODULE_6__["Tab2Page"] }])
        ],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_6__["Tab2Page"]]
    })
], Tab2PageModule);



/***/ }),

/***/ "./src/app/tab2/tab2.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".sign_btn {\n  display: block;\n  width: 80%;\n  margin: 0px auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMi9DOlxcaW9uaWNcXGNhcnRcXGNhcnRWaWV3L3NyY1xcYXBwXFx0YWIyXFx0YWIyLnBhZ2Uuc2NzcyIsInNyYy9hcHAvdGFiMi90YWIyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3RhYjIvdGFiMi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2lnbl9idG57XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgd2lkdGg6IDgwJTtcbiAgICBtYXJnaW46IDBweCBhdXRvO1xufVxuIiwiLnNpZ25fYnRuIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHdpZHRoOiA4MCU7XG4gIG1hcmdpbjogMHB4IGF1dG87XG59Il19 */"

/***/ }),

/***/ "./src/app/tab2/tab2.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab2/tab2.page.ts ***!
  \***********************************/
/*! exports provided: Tab2Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab2Page", function() { return Tab2Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/http.service */ "./src/app/services/http.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





let Tab2Page = class Tab2Page {
    constructor(http, storage, nav) {
        this.http = http;
        this.storage = storage;
        this.nav = nav;
        this.token = '';
        this.mid = '';
        this.gid = '';
        this.cid = '';
    }
    ionViewWillEnter() {
        this.token = localStorage.getItem('token');
        if (this.token != null) {
            var info = this.token.split(".")[1];
            var username = JSON.parse(window.atob(info)).name;
            this.getManagerId(username);
        }
        else {
            //localStorage.setItem('redirect', location.href);
            //window.location.href = 'http://localhost:8200/tabs/tab1?order=checkLogin&redirect=' + window.location.origin + '/redirect';
            this.nav.navigateForward('/login');
        }
    }
    getManagerId(username) {
        this.http.ajaxGet('/market/manager/getMidByUsername?username=' + username + '&token=' + this.token).then((response) => {
            console.log(response);
            if (response.status == 200) {
                this.mid = response.data;
                console.log(this.mid);
                this.initCompany(this.mid);
            }
            else if (response.status == -1) {
                alert(response.msg);
                //localStorage.setItem('redirect', location.href);
                //window.location.href = 'http://localhost:8200/tabs/tab1?order=checkLogin&redirect=' + window.location.origin + '/redirect';
                this.nav.navigateForward('/login');
            }
            else {
                console.log(response.msg);
            }
        });
    }
    initCompany(mid) {
        this.http.ajaxGet("/market/company/getCompanyList?mid=" + mid + "&token=" + this.token).then((response) => {
            console.log(response);
            if (response.status == 200) {
                this.companys = response.data;
            }
            else if (response.status == -1) {
                alert(response.msg);
                //localStorage.setItem('redirect', location.href);
                //window.location.href = 'http://localhost:8200/tabs/tab1?order=checkLogin&redirect=' + window.location.origin + '/redirect';
                this.nav.navigateForward('/login');
            }
            else {
                alert(response.msg);
            }
        });
    }
    initCust() {
        this.http.ajaxGet("/market/cust/getCustList?gid=" + this.gid + "&token=" + this.token).then((response) => {
            console.log(response);
            if (response.status == 200) {
                this.custs = response.data;
            }
            else if (response.status == -1) {
                alert(response.msg);
                //localStorage.setItem('redirect', location.href);
                //window.location.href = 'http://localhost:8200/tabs/tab1?order=checkLogin&redirect=' + window.location.origin + '/redirect';
                this.nav.navigateForward('/login');
            }
            else {
                alert(response.msg);
            }
        });
    }
    hasCid() {
        if (this.cid != null) {
            this.signBtn.disabled = false;
        }
        else {
            this.signBtn.disabled = true;
        }
    }
    toSign(cid) {
        this.cid = cid;
        this.storage.set("gid", this.gid);
        this.storage.set("cid", cid);
        this.storage.set("mid", this.mid);
        this.http.ajaxGet("/market/sso/getCode?cid=" + cid).then((response) => {
            console.log(response);
            if (response.status == 200) {
                this.storage.set('phone', response.data);
                this.nav.navigateForward('/code');
            }
            else {
                alert('发送验证码失败' + response.msg);
            }
        });
        //this.nav.navigateForward("/sign-page");
    }
    toView(cid) {
        this.nav.navigateForward(['/sign-view'], {
            queryParams: {
                cid: cid
            }
        });
    }
};
Tab2Page.ctorParameters = () => [
    { type: _services_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("signBtn", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], Tab2Page.prototype, "signBtn", void 0);
Tab2Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tab2',
        template: __webpack_require__(/*! raw-loader!./tab2.page.html */ "./node_modules/raw-loader/index.js!./src/app/tab2/tab2.page.html"),
        styles: [__webpack_require__(/*! ./tab2.page.scss */ "./src/app/tab2/tab2.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"], _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])
], Tab2Page);



/***/ })

}]);
//# sourceMappingURL=tab2-tab2-module-es2015.js.map