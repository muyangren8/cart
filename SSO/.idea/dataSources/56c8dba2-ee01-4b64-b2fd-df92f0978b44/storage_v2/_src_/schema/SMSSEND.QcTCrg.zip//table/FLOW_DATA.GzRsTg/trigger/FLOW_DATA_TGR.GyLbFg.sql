create trigger FLOW_DATA_TGR
    before insert
    on FLOW_DATA
    for each row
BEGIN
SELECT FLOW_DATA_SEQ.NextVAl INTO :new.ID FROM dual;
END;
/

