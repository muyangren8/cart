create trigger LZJ_AUTO_ID
    before insert
    on LZJ
    for each row
BEGIN
SELECT LZJ_SEQUENCE.NextVAl INTO :new.ID FROM dual;
END;

/

