create trigger "SCHOOL_AUTO_ID_copy"
    before insert
    on FFD
    for each row
BEGIN
SELECT school_sequence.NextVAl INTO :new.ID FROM dual;
END;


/

