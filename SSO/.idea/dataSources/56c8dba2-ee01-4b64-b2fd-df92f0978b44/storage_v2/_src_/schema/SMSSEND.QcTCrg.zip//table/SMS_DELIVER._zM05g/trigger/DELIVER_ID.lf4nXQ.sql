create trigger DELIVER_ID
    before insert
    on SMS_DELIVER
    for each row
BEGIN
SELECT EMP_SEQUENCE_DELIVER.NextVAl INTO :new.ID FROM dual;
END;
/

