create trigger SCHOOL_AUTO_ID
    before insert
    on SCHOOL
    for each row
BEGIN
SELECT school_sequence.NextVAl INTO :new.ID FROM dual;
END;


/

